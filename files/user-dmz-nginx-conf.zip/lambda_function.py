import unittest
from unittest.mock import patch
from lambda_handler import lambda_handler

class TestLambdaFunction(unittest.TestCase):
    
    @patch('builtins.print')  # print 문을 모킹하여 출력 확인
    @patch('paramiko.SSHClient')  # SSHClient를 모킹하여 SSH 연결을 테스트
    @patch('boto3.client')  # boto3.client를 모킹하여 EC2 클라이언트 생성을 테스트
    def test_lambda_handler(self, mock_boto3_client, mock_ssh_client, mock_print):
        # 테스트용 EC2 인스턴스의 반환 값을 설정합니다.
        mock_boto3_client.return_value.describe_instances.return_value = {
            'Reservations': [{
                'Instances': [{
                    'PublicIpAddress': 'test_public_ip'
                }]
            }]
        }
        # 테스트용 SSHClient의 exec_command 메서드의 반환 값을 설정합니다.
        mock_ssh_client.return_value.exec_command.return_value = (None, None, None)
        
        # Lambda 함수를 호출합니다.
        lambda_handler({}, None)
        lambda_handler({}, None)
        
        # Lambda 함수가 파일을 성공적으로 변경했는지 확인합니다.
        mock_print.assert_called_with('Successfully updated file on instance your-instance-id')
    
            
if __name__ == '__main__':
    unittest.main()