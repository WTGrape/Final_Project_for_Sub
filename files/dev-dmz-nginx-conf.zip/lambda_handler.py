import boto3
import paramiko
import os

def get_load_balancer_ip(load_balancer_name, tag_key, tag_value):
    # Create ELB/ALB client
    elbv2 = boto3.client('elbv2')
    
    # Get Load Balancer ARN using tags
    response = elbv2.describe_load_balancers()
    load_balancer_arn = None
    for lb in response['LoadBalancers']:
        tags = elbv2.describe_tags(ResourceArns=[lb['LoadBalancerArn']])
        for tag in tags['TagDescriptions'][0]['Tags']:
            if tag['Key'] == tag_key and tag['Value'] == tag_value:
                load_balancer_arn = lb['LoadBalancerArn']
                break
    
    # Get Load Balancer details and extract endpoint IP(s)
    if load_balancer_arn:
        response = elbv2.describe_load_balancers(LoadBalancerArns=[load_balancer_arn])
        ips = response['LoadBalancers'][0]['DNSName']
        return ips
    else:
        return None

def lambda_handler(event, context):
    # Auto Scaling 클라이언트 생성
    
    load_balancer_name = 'dev-load-balancer'
    tag_key = 'Role'
    tag_value = 'test-dev-was'
    
    dns_name = get_load_balancer_ip(load_balancer_name, tag_key, tag_value)
    
    
    
    autoscaling_client = boto3.client('autoscaling')
    
    # 변경할 파일 경로 및 내용
    file_path = '/etc/nginx/nginx.conf'
    current_path = os.path.dirname(os.path.realpath(__file__))
    nginx_file_path = os.path.join(current_path, 'nginx.conf')
    try:
        # 파일 열기
        with open(nginx_file_path, 'r') as file:
            # 파일 내용 읽기
            file_content = file.read()
            
            # 파일 내용을 변수에 저장
            # 이 변수를 다른 작업에 사용할 수 있습니다.
            saved_content = file_content
            
                
    except Exception as e:
        print(f"Error: {str(e)}")
    
    
    new_content = saved_content
    
    # Auto Scaling 그룹의 태그 키와 값 설정
    tag_key = 'Name'
    tag_value0 = 'dev_dmz_proxy-0'
    tag_value1 = 'dev_dmz_proxy-1'
    try:
        # Auto Scaling 그룹에서 EC2 인스턴스 목록 가져오기
        response = autoscaling_client.describe_auto_scaling_groups()
        for group in response['AutoScalingGroups']:
            tags = group.get('Tags', [])
            for tag in tags:
                if tag['Key'] == tag_key and tag['Value'] == tag_value0:
                    instances = [i['InstanceId'] for i in group['Instances']]
                    # 인스턴스마다 파일 변경 명령 실행
                    for instance_id in instances:
                        print(instance_id)
                        # EC2 인스턴스 정보 가져오기
                        ec2_client = boto3.client('ec2')
                        response = ec2_client.describe_instances(InstanceIds=[instance_id])
                        instance_ip = response['Reservations'][0]['Instances'][0]['PrivateIpAddress']
                        
                        # SSH 클라이언트 생성
                        ssh_client = paramiko.SSHClient()
                        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                        
                        # SSH 연결
                        ssh_client.connect(instance_ip, username='ec2-user', key_filename='terraform-key')
                        
                        # 파일 변경 명령 실행
                        #command = f'sudo echo "{new_content}" > {file_path}'
                        command = f'sudo sh -c "echo \\"{new_content}\\" > {file_path}"'
                        stdin, stdout, stderr = ssh_client.exec_command(command)
                        
                        if None!= dns_name:
                            print('test0001')
                            command = f"sudo sed -i 's|proxy_pass .*|proxy_pass http://{dns_name};|g' /etc/nginx/nginx.conf"
                            stdin, stdout, stderr = ssh_client.exec_command(command)
                        command = f'sudo sh -c "systemctl restart nginx"'
                        stdin, stdout, stderr = ssh_client.exec_command(command)
                        
                        
                        
                        # 결과 확인
                        if not stderr.channel.recv_exit_status():
                            print(f"Successfully updated file on instance {instance_id}")
                        else:
                            print(f"Failed to update file on instance {instance_id}: {stderr.read().decode()}")
                        
                        # SSH 연결 종료
                        ssh_client.close()
                elif tag['Key'] == tag_key and tag['Value'] == tag_value1:
                    instances = [i['InstanceId'] for i in group['Instances']]
                    # 인스턴스마다 파일 변경 명령 실행
                    for instance_id in instances:
                        print(instance_id)
                        # EC2 인스턴스 정보 가져오기
                        ec2_client = boto3.client('ec2')
                        response = ec2_client.describe_instances(InstanceIds=[instance_id])
                        instance_ip = response['Reservations'][0]['Instances'][0]['PrivateIpAddress']
                        
                        # SSH 클라이언트 생성
                        ssh_client = paramiko.SSHClient()
                        ssh_client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
                        
                        # SSH 연결
                        ssh_client.connect(instance_ip, username='ec2-user', key_filename='terraform-key')
                        
                        # 파일 변경 명령 실행
                        #command = f'sudo echo "{new_content}" > {file_path}'
                        command = f'sudo sh -c "echo \\"{new_content}\\" > {file_path}"'
                        stdin, stdout, stderr = ssh_client.exec_command(command)
                        command = f'sudo sh -c "systemctl status nginx"'
                        stdin, stdout, stderr = ssh_client.exec_command(command)
                        if None!= dns_name:
                            command = f"sudo sed -i 's|proxy_pass .*|proxy_pass http://{dns_name};|g' /etc/nginx/nginx.conf"
                            stdin, stdout, stderr = ssh_client.exec_command(command)
                        command = f'sudo sh -c "systemctl restart nginx"'
                        stdin, stdout, stderr = ssh_client.exec_command(command)
                        
                        # 결과 확인
                        if not stderr.channel.recv_exit_status():
                            print(f"Successfully updated file on instance {instance_id}")
                        else:
                            print(f"Failed to update file on instance {instance_id}: {stderr.read().decode()}")
                        
                        # SSH 연결 종료
                        ssh_client.close()
    except Exception as e:
        print(f"Error: {str(e)}")